<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Services\Payments\LiveGroup;
use App\Models\Orders;

class PaymentController extends Controller
{
    // create hosted checkout
    public function createIntent(Request $r, LiveGroup $lg)
    {
        $v = Validator::make($r->all(), ['order_id' => 'required|integer|exists:orders,id']);
        if ($v->fails()) return response()->json(['error' => $v->errors()], 422);

        $order = Orders::findOrFail($r->order_id);

        if (strcasecmp($order->workflow ?? '', 'Payment Requested') !== 0) {
            return response()->json([
                'error' => 'Order not ready for payment',
                'workflow' => $order->workflow,
            ], 409);
        }

        $amountCents = (int) round($order->total_price * 100);

        $payload = [
            'amount'     => $amountCents,
            'currency'   => 'AUD',
            'capture'    => true,
            'reference'  => "ORD-{$order->id}",
            'return_url' => url('/api/payments/return'),
            'metadata'   => ['order_id' => $order->id],
        ];

        $res = $lg->createIntent($payload);

        return response()->json([
            'intent_id'    => $res['id'] ?? null,
            'redirect_url' => $res['checkout_url'] ?? null,
            'amount_cents' => $amountCents
        ]);
    }

    // handle return: verify payment directly with gateway
    public function handleReturn(Request $r, LiveGroup $lg)
    {
        $intentId = $r->query('intent_id');
        if (!$intentId) return response()->json(['error' => 'missing intent_id'], 400);

        $remote = $lg->getIntent($intentId);
        $status = strtolower($remote['status'] ?? '');

        if (in_array($status, ['succeeded','captured','paid'], true)) {
            return response()->json([
                'status' => 'paid',
                'transaction_id' => $remote['transaction_id'] ?? null,
                'gateway_response' => $remote
            ]);
        }

        return response()->json([
            'status' => 'unpaid',
            'gateway_response' => $remote
        ]);
    }
}
